package com.tech.major.global;

import java.util.ArrayList;
import java.util.List;

import com.tech.major.model.Product;

public class Myoder 
{
	public static List<Product> cart;
	static {
		cart = new ArrayList<Product>();
	}


}
